// script.js

// --- DOM Elements ---
const container = document.querySelector('.container');
const timeDisplay = document.getElementById('time');
const greetingDisplay = document.querySelector('.greeting');
const quickLinksContainer = document.querySelector('.quick-links');

// Add Shortcut Modal elements
const addModal = document.getElementById('add-shortcut-modal');
const addCloseButton = addModal.querySelector('.close-button');
const addShortcutForm = document.getElementById('add-shortcut-form');
const addShortcutNameInput = document.getElementById('shortcut-name');
const addShortcutUrlInput = document.getElementById('shortcut-url');

// Edit Shortcut Modal elements
const editModal = document.getElementById('edit-shortcut-modal');
const editCloseButton = editModal.querySelector('.close-button');
const editShortcutForm = document.getElementById('edit-shortcut-form');
const editShortcutIndexInput = document.getElementById('edit-shortcut-index');
const editShortcutNameInput = document.getElementById('edit-shortcut-name');
const editShortcutUrlInput = document.getElementById('edit-shortcut-url');
const deleteShortcutButton = document.getElementById('delete-shortcut-button');


// Settings Panel elements
const settingsIcon = document.getElementById('settings-icon');
const settingsPanel = document.getElementById('settings-panel');
const settingsCloseButton = settingsPanel.querySelector('.close-button');
const settingsForm = document.getElementById('settings-form');
const bgTypeToggle = document.getElementById('bg-type-toggle'); // Checkbox for gradient
const bgColorStartInput = document.getElementById('bg-color-start'); // Color picker 1
const bgColorEndInput = document.getElementById('bg-color-end'); // Color picker 2
const bgColorEndGroup = document.getElementById('bg-color-end-group'); // Container for color picker 2
const textColorInput = document.getElementById('text-color'); // Text color picker

// Add these new references for local image upload and remove button
const bgImageUploadInput = document.getElementById('bg-image-upload'); // File input
const fileUploadInfo = document.getElementById('file-upload-info');     // Paragraph for file name
const removeBgImageButton = document.getElementById('remove-bg-image-button'); // <-- Reference to the button


// --- Storage Keys ---
const STORAGE_KEY_SHORTCUTS = 'customNewTabShortcuts';
const STORAGE_KEY_SETTINGS = 'customNewTabSettings'; // Key for storing settings (excluding image data)

// --- IndexedDB Constants ---
const DB_NAME = 'CustomNewTabDB';
const DB_VERSION = 1;
const OBJECT_STORE_NAME = 'backgroundImages';
const IMAGE_KEY = 'backgroundImage'; // Key to store the single background image

// --- Global State ---
let currentShortcuts = []; // Store the currently loaded shortcuts array
let currentSettings = {}; // Store the currently loaded settings object (excluding image data)
let db; // Variable to hold the IndexedDB database connection


// --- IndexedDB Functions ---

// Function to open the IndexedDB database
function openDatabase() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onerror = (event) => {
            console.error("IndexedDB database error:", event.target.errorCode);
            reject("Database error: " + event.target.errorCode);
        };

        request.onsuccess = (event) => {
            db = event.target.result;
            console.log("IndexedDB database opened successfully");
            resolve(db);
        };

        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            // Create an object store for background images
            if (!db.objectStoreNames.contains(OBJECT_STORE_NAME)) {
                db.createObjectStore(OBJECT_STORE_NAME);
                console.log("Object store created:", OBJECT_STORE_NAME);
            }
        };
    });
}

// Function to save the background image (Blob) to IndexedDB
function saveBackgroundImage(imageBlob) {
    return new Promise((resolve, reject) => {
        if (!db) {
             reject("IndexedDB not initialized.");
             return;
        }
        // Use 'readwrite' mode for adding or modifying data
        const transaction = db.transaction([OBJECT_STORE_NAME], 'readwrite');

        transaction.onerror = (event) => {
             console.error("Transaction error while saving image:", event.target.error);
             reject("Transaction error: " + event.target.error);
        };

        transaction.oncomplete = () => {
            console.log("Background image saved to IndexedDB.");
            resolve();
        };

        const objectStore = transaction.objectStore(OBJECT_STORE_NAME);

        // Put (add or update) the image Blob with a specific key
        const putRequest = objectStore.put(imageBlob, IMAGE_KEY);

        putRequest.onerror = (event) => {
            console.error("Put request error while saving image:", event.target.error);
            reject("Put request error: " + event.target.error);
        };
    });
}

// Function to get the background image (Blob) from IndexedDB
function getBackgroundImage() {
    return new Promise((resolve, reject) => {
         if (!db) {
             reject("IndexedDB not initialized.");
             return;
        }
        // Use 'readonly' mode for fetching data
        const transaction = db.transaction([OBJECT_STORE_NAME], 'readonly');

        transaction.onerror = (event) => {
             console.error("Transaction error while getting image:", event.target.error);
             reject("Transaction error: " + event.target.error);
        };

        transaction.oncomplete = () => {
            console.log("Background image retrieved from IndexedDB.");
        };

        const objectStore = transaction.objectStore(OBJECT_STORE_NAME);

        // Get the image Blob using its key
        const getRequest = objectStore.get(IMAGE_KEY);

        getRequest.onerror = (event) => {
            console.error("Get request error while getting image:", event.target.error);
            reject("Get request error: " + event.target.error);
        };

        getRequest.onsuccess = (event) => {
            // Resolve with the Blob data if found, otherwise resolve with undefined
            resolve(event.target.result);
        };
    });
}

// Function to delete the background image from IndexedDB
function deleteBackgroundImage() {
    return new Promise((resolve, reject) => {
         if (!db) {
             reject("IndexedDB not initialized.");
             return;
        }
        // Use 'readwrite' mode for deleting data
        const transaction = db.transaction([OBJECT_STORE_NAME], 'readwrite');

        transaction.onerror = (event) => {
             console.error("Transaction error while deleting image:", event.target.error);
             reject("Transaction error: " + event.target.error);
        };

        transaction.oncomplete = () => {
            console.log("Background image deleted from IndexedDB.");
            resolve();
        };

        const objectStore = transaction.objectStore(OBJECT_STORE_NAME);

        // Delete the image using its key
        const deleteRequest = objectStore.delete(IMAGE_KEY);

        deleteRequest.onerror = (event) => {
             console.error("Delete request error while deleting image:", event.target.error);
             reject("Delete request error: " + event.target.error);
        };
    });
}


// --- Functions (Rest of the code, modified to use IndexedDB for image) ---

// Function to update time and greeting
function updateTimeAndGreeting() {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();

    const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    timeDisplay.textContent = formattedTime;

    let greeting;
    if (hours < 12) {
        greeting = 'Good Morning!';
    } else if (hours < 18) {
        greeting = 'Good Afternoon!';
    } else {
        greeting = 'Good Evening!';
    }
    greetingDisplay.textContent = greeting;
}

// Function to display a single shortcut in the DOM
function displayShortcut(shortcut, index) {
    const linkItem = document.createElement('a');
    linkItem.href = shortcut.url;
    linkItem.target = '_blank'; // Open link in a new tab
    linkItem.classList.add('link-item');
    linkItem.title = `${shortcut.name}\n${shortcut.url}`; // Add tooltip
    linkItem.dataset.index = index; // Store the index on the element

    const iconImg = document.createElement('img');
    const faviconUrl = `https://www.google.com/s2/favicons?sz=32&domain=${encodeURIComponent(shortcut.url)}`;
    iconImg.src = faviconUrl;
    iconImg.alt = `${shortcut.name} icon`;
    iconImg.onerror = () => {
        iconImg.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUAAABAAAAAQCAQAAAC1+nPcAAAAE0lEQVR42mNkYAYAAf+gGA0D9w18AAAAAElFTkSuQmCC'; // Simple placeholder icon
        iconImg.alt = 'Default icon';
    };

    const nameSpan = document.createElement('span');
    nameSpan.textContent = shortcut.name;

    // Create the edit icon element
    const editIcon = document.createElement('div');
    editIcon.classList.add('edit-icon');
    editIcon.textContent = '...'; // Using text dots as the icon

    // Add event listener to the edit icon
    editIcon.addEventListener('click', (e) => {
        e.preventDefault(); // Prevent triggering the link
        e.stopPropagation(); // Stop the click event from bubbling up to the link item

        const clickedIndex = parseInt(linkItem.dataset.index, 10); // Get index from data attribute
        openEditShortcutModal(clickedIndex, currentShortcuts[clickedIndex]); // Open edit modal
    });


    linkItem.appendChild(iconImg);
    linkItem.appendChild(nameSpan);
    linkItem.appendChild(editIcon); // Add the edit icon
    quickLinksContainer.appendChild(linkItem);
}

// Function to load shortcuts from storage
function loadShortcuts() {
    chrome.storage.local.get([STORAGE_KEY_SHORTCUTS], (result) => {
        currentShortcuts = result?.[STORAGE_KEY_SHORTCUTS] || []; // Use optional chaining for safety
        quickLinksContainer.innerHTML = ''; // Clear existing links before loading
        currentShortcuts.forEach((shortcut, index) => { // Pass index during display
            displayShortcut(shortcut, index);
        });
    });
}

// Function to save shortcuts to storage
function saveShortcuts(shortcuts) {
    currentShortcuts = shortcuts; // Update global state before saving
    chrome.storage.local.set({ [STORAGE_KEY_SHORTCUTS]: shortcuts }, () => {
        console.log('Shortcuts saved to storage.');
    });
}

// Function to add a new shortcut
function addShortcut(name, url) {
    // Basic URL validation and normalization
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url; // Prepend https:// if missing
    }

    const newShortcut = { name, url };

    // Get existing shortcuts, add new one, save, and reload display
    chrome.storage.local.get([STORAGE_KEY_SHORTCUTS], (result) => {
        const shortcuts = result?.[STORAGE_KEY_SHORTCUTS] || []; // Use optional chaining
        shortcuts.push(newShortcut);
        saveShortcuts(shortcuts); // Saves to storage and updates global state
        loadShortcuts(); // Reload the display to show the new shortcut with correct index
    });
}

// Function to edit an existing shortcut
function saveEditedShortcut(index, newName, newUrl) {
     // Basic URL validation and normalization for edited URL
    if (!newUrl.startsWith('http://') && !newUrl.startsWith('https://')) {
        newUrl = 'https://' + newUrl; // Prepend https:// if missing
    }

    // Use the globally stored currentShortcuts array
    if (index >= 0 && index < currentShortcuts.length) {
        currentShortcuts[index].name = newName;
        currentShortcuts[index].url = newUrl;
        saveShortcuts(currentShortcuts); // Saves to storage and updates global state
        loadShortcuts(); // Reload the display to show the updated shortcut
    } else {
        console.error("Invalid shortcut index for editing:", index);
        // Optionally alert the user
    }
}

// Function to delete a shortcut
function deleteShortcut(index) {
     // Use the globally stored currentShortcuts array
    if (index >= 0 && index < currentShortcuts.length) {
        // Remove the item at the given index
        currentShortcuts.splice(index, 1);
        saveShortcuts(currentShortcuts); // Saves to storage and updates global state
        loadShortcuts(); // Reload the display
    } else {
        console.error("Invalid shortcut index for deleting:", index);
        // Optionally alert the user
    }
}


// --- Settings Functions ---

// Function to load settings from storage and apply them
async function loadSettings() {
    // Load regular settings from chrome.storage.local
    const storageResult = await chrome.storage.local.get([STORAGE_KEY_SETTINGS]);
    currentSettings = storageResult?.[STORAGE_KEY_SETTINGS] || {}; // Load or initialize settings

    // Load background image from IndexedDB
    let backgroundImageBlob = null;
    try {
        backgroundImageBlob = await getBackgroundImage();
        // Store the loaded Blob temporarily in currentSettings for form population/display
        currentSettings.bgImageBlob = backgroundImageBlob;
        // Determine background type based on whether image was loaded
         if (backgroundImageBlob) {
              currentSettings.bgType = 'image';
         } else if (!currentSettings.bgType) {
             // If no image and no type saved, default to gradient
             currentSettings.bgType = 'gradient';
         }

    } catch (error) {
        console.error("Failed to load background image from IndexedDB:", error);
        currentSettings.bgImageBlob = null; // Ensure it's null on error
         // If loading failed and no type was saved, default to gradient
         if (!currentSettings.bgType) {
             currentSettings.bgType = 'gradient';
         }
    }

    // Apply loaded settings to the page
    applySettings(currentSettings);

    // Populate settings form with loaded values
    populateSettingsForm(currentSettings);

    // Update the state of image-related inputs
    updateInputStates();
}

// Function to apply settings to the page's style
function applySettings(settings) {
    const root = document.documentElement; // The :root element (<html>)

    // Apply background style
    // Prioritize image blob if it exists and type is 'image'
    if (settings.bgType === 'image' && settings.bgImageBlob instanceof Blob) {
         // Create a Data URL from the Blob for use in CSS
         const imageUrl = URL.createObjectURL(settings.bgImageBlob);

         // Remove any gradient or solid background applied previously
         document.body.style.backgroundColor = '';
         document.body.style.backgroundImage = `url('${imageUrl}')`; // Use the created Data URL
         document.body.style.backgroundSize = 'cover';
         document.body.style.backgroundPosition = 'center';
         document.body.style.backgroundRepeat = 'no-repeat';
         // Fallback colors for variables
         root.style.setProperty('--bg-gradient-start', '#111111');
         root.style.setProperty('--bg-gradient-end', '#5f3a9c');

         // Revoke the object URL after the image has loaded to free up memory
         // This is a bit tricky with background images set via CSS.
         // A simple approach is to revoke after a short delay, assuming the browser has processed it.
         // A more robust approach would involve waiting for a load event if we were using <img>.
         // For simplicity here, we use a delay.
         setTimeout(() => URL.revokeObjectURL(imageUrl), 100);


    } else if (settings.bgType === 'solid') {
        // Remove any image or gradient applied previously
        document.body.style.backgroundImage = '';
        document.body.style.backgroundSize = '';
        document.body.style.backgroundPosition = '';
        document.body.style.backgroundRepeat = '';
        // Revoke any lingering object URL if applicable
        if (settings.bgImageBlob && settings.bgImageBlob instanceof Blob) {
             // This case shouldn't happen if logic is followed, but good for cleanup
             // No, revoke is handled when applying the image. Leave this out here.
        }

        document.body.style.backgroundColor = settings.bgColor1 || '#111111';
         root.style.setProperty('--bg-gradient-start', settings.bgColor1 || '#111111'); // Also update variables
         root.style.setProperty('--bg-gradient-end', settings.bgColor1 || '#111111');

    } else { // Default to gradient
        // Remove any image or solid color applied previously
        document.body.style.backgroundColor = '';
        document.body.style.backgroundSize = '';
        document.body.style.backgroundPosition = '';
        document.body.style.backgroundRepeat = '';
        // Revoke any lingering object URL if applicable
         if (settings.bgImageBlob && settings.bgImageBlob instanceof Blob) {
              // This case shouldn't happen if logic is followed, but good for cleanup
             // No, revoke is handled when applying the image. Leave this out here.
         }

        root.style.setProperty('--bg-gradient-start', settings.bgColor1 || '#111111');
        root.style.setProperty('--bg-gradient-end', settings.bgColor2 || '#5f3a9c');
        document.body.style.backgroundImage = `linear-gradient(to bottom right, var(--bg-gradient-start), var(--bg-gradient-end))`;
    }

    // Apply text color
    if (settings.textColor) {
        root.style.setProperty('--text-color', settings.textColor);
        root.style.setProperty('--heading-color', settings.textColor);
         root.style.setProperty('--dark-color', settings.textColor);
    } else {
        // Reset to default CSS variable values if no setting
         root.style.setProperty('--text-color', '#cdd');
         root.style.setProperty('--heading-color', '#ffffff');
         root.style.setProperty('--dark-color', '#cdd');
    }
}

// Function to populate the settings form with current settings
function populateSettingsForm(settings) {
    // Background Type Toggle: Checked if using gradient
    // Toggle is disabled if an image blob exists
    const isImageSet = settings.bgImageBlob instanceof Blob;
    const isGradient = settings.bgType === 'gradient';

    bgTypeToggle.checked = isGradient;
    bgTypeToggle.disabled = isImageSet; // Disable toggle if image is set

    // Background Colors
    bgColorStartInput.value = settings.bgColor1 || '#111111';
    bgColorEndInput.value = settings.bgColor2 || '#5f3a9c';

    // File Input Info: Show message if image blob exists
    fileUploadInfo.textContent = isImageSet ? 'Custom image loaded' : '';

    // Text Color
    textColorInput.value = settings.textColor || '#cdd'; // Default light text color

    // Update visibility/state of related fields
    toggleGradientFields(isGradient && !isImageSet); // Hide color 2 if image is set
    updateInputStates(); // Call the state update function to handle disabled/opacity
}

// Function to toggle visibility of the second gradient color input
function toggleGradientFields(show) {
    bgColorEndGroup.style.display = show ? 'block' : 'none';
    // Note: Disabled state is handled in updateInputStates now
}

// Central function to update the disabled/opacity states of inputs
function updateInputStates() {
     const isGradient = bgTypeToggle.checked; // Read current state from the toggle
     const isImageSet = currentSettings.bgImageBlob instanceof Blob; // Check if image data exists in global state (as Blob)

     // File input is disabled if gradient is ON
     bgImageUploadInput.disabled = isGradient;
     bgImageUploadInput.style.opacity = isGradient ? '0.5' : '1';
      // If file input is disabled, clear its visual value
     if (isGradient) {
          bgImageUploadInput.value = ''; // Clear the selected file visually
     }
      // Update file info text based on whether image data exists
      fileUploadInfo.textContent = isImageSet ? 'Custom image loaded' : '';


     // Color pickers are disabled if image is SET
     bgColorStartInput.disabled = isImageSet;
     // Color 2 is disabled if image is SET OR if gradient is OFF
     bgColorEndInput.disabled = isImageSet || !isGradient;

     bgColorStartInput.style.opacity = isImageSet ? '0.5' : '1';
     bgColorEndInput.style.opacity = (isImageSet || !isGradient) ? '0.5' : '1';

     // Remove image button is enabled only if an image is SET
     removeBgImageButton.disabled = !isImageSet;
     removeBgImageButton.style.opacity = !isImageSet ? '0.5' : '1';

     // Gradient toggle is disabled if image is SET
     bgTypeToggle.disabled = isImageSet;
     bgTypeToggle.style.opacity = isImageSet ? '0.5' : '1';

     // Update Color 1 label based on background type
      document.getElementById('label-bg-color-start').textContent = isImageSet ? 'Background Color:' : (isGradient ? 'Color 1 (Start):' : 'Solid Color:');

       // Also update visibility of Color 2 group based on gradient state and image state
       bgColorEndGroup.style.display = isGradient && !isImageSet ? 'block' : 'none';
}


// Function to save settings from the form
async function saveSettingsFromForm() {
    // Determine the background type based on global state (which holds image blob)
    const bgType = currentSettings.bgImageBlob instanceof Blob ? 'image' : (bgTypeToggle.checked ? 'gradient' : 'solid');

    const bgColor1 = bgColorStartInput.value;
    const bgColor2 = bgColorEndInput.value;
    const textColor = textColorInput.value;

    // Settings to save to chrome.storage.local (EXCLUDING image data)
    const settingsToSaveLocal = {
        bgType: bgType,
        bgColor1: bgColor1,
        bgColor2: bgType === 'gradient' ? bgColor2 : undefined, // Only save color2 if gradient is on
        textColor: textColor
    };

    // Handle saving/deleting the image in IndexedDB
    if (bgType === 'image' && currentSettings.bgImageBlob instanceof Blob) {
         try {
             await saveBackgroundImage(currentSettings.bgImageBlob);
             console.log("Background image saved to IndexedDB successfully.");
         } catch (error) {
             console.error("Error saving background image to IndexedDB:", error);
             alert("Failed to save background image. Please try again.");
              // Revert to previous state if saving image fails? Or let the user retry?
              // For now, just log the error and continue saving other settings.
              settingsToSaveLocal.bgType = currentSettings.bgType || 'gradient'; // Revert type in local storage
         }
    } else if (currentSettings.bgImageBlob === null) {
         // If bgImageBlob is explicitly set to null (via remove button), delete from DB
        try {
            await deleteBackgroundImage();
            console.log("Background image deleted from IndexedDB successfully.");
        } catch (error) {
             console.warn("Could not delete background image from IndexedDB (it might not have been there):", error);
             // Continue even if deletion fails
        }
    }
     // Note: If bgType is not 'image' and bgImageBlob is not null, it means the user
     // switched to gradient/solid *before* saving the image. In this case, we don't save the new image,
     // and the existing one (if any) remains until explicitly removed or overwritten.
     // The logic below ensures we save the *intended* settings state to local storage.


    // Save regular settings to chrome.storage.local
    chrome.storage.local.set({ [STORAGE_KEY_SETTINGS]: settingsToSaveLocal }, () => {
        console.log('Regular settings saved to storage.');
        // Update global state with the local storage settings
        currentSettings.bgType = settingsToSaveLocal.bgType;
        currentSettings.bgColor1 = settingsToSaveLocal.bgColor1;
        currentSettings.bgColor2 = settingsToSaveLocal.bgColor2;
        currentSettings.textColor = settingsToSaveLocal.textColor;

        // Re-apply settings and update UI based on the *actual* state (including IndexedDB image)
        // We need to reload the image state from IndexedDB to be certain after saving
        loadSettings(); // This will load everything again and update the UI

        closeSettingsPanel(); // Close the panel after saving and reloading
    });
}


// Function to show the settings panel
function openSettingsPanel() {
    settingsPanel.classList.add('open');
    // Populate form with current settings when opening
    // loadSettings() was called on DOMContentLoaded, so currentSettings should be up-to-date
    populateSettingsForm(currentSettings); // Ensure UI matches current state
    updateInputStates(); // Ensure disabled states are correct upon opening
}

// Function to hide the settings panel
function closeSettingsPanel() {
    settingsPanel.classList.remove('open');

    // When closing without saving, reset inputs to match the currentSettings state
     // Re-loading settings from storage is the safest way to revert unsaved changes
     loadSettings(); // This will fetch current saved settings and apply them
}


// Function to show the ADD modal (called by message from service worker)
function showAddShortcutModal() {
    addModal.style.display = 'flex'; // Show the modal (flex for centering)
    // Apply modal animation
    addModal.querySelector('.modal-content').style.animation = 'modalShow 0.3s ease-out forwards';
    addShortcutNameInput.focus();     // Focus the first input field
}

// Function to show the EDIT modal
function openEditShortcutModal(index, shortcut) {
    editModal.style.display = 'flex'; // Show the modal
     // Apply modal animation
    editModal.querySelector('.modal-content').style.animation = 'modalShow 0.3s ease-out forwards';

    // Populate the form fields
    editShortcutIndexInput.value = index; // Store the index
    editShortcutNameInput.value = shortcut.name;
    editShortcutUrlInput.value = shortcut.url;

    editShortcutNameInput.focus(); // Focus the first input field
}

// --- Event Listeners ---

// Listen for messages from the service worker (to open the ADD modal)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "openAddShortcutModal") {
        showAddShortcutModal();
        sendResponse({ status: "add modal opening" });
        return true; // Indicates that the response is sent asynchronously
    }
    // Handle other potential messages here
});


// Handle click on ADD modal close button to close modal
addCloseButton.addEventListener('click', () => { // Listener only on close button
    addModal.style.display = 'none';
    addShortcutForm.reset(); // Reset the form fields
     // Remove animation style when closing
    addModal.querySelector('.modal-content').style.animation = '';
});

// Handle click on EDIT modal close button to close modal
editCloseButton.addEventListener('click', () => { // Listener only on close button
    editModal.style.display = 'none';
    editShortcutForm.reset(); // Reset the form fields
     // Remove animation style when closing
    editModal.querySelector('.modal-content').style.animation = '';
});


// Handle ADD form submission
addShortcutForm.addEventListener('submit', (event) => {
    event.preventDefault(); // Prevent default form submission

    const name = addShortcutNameInput.value.trim();
    const url = addShortcutUrlInput.value.trim();

    if (name && url) {
        addShortcut(name, url);
        addModal.style.display = 'none'; // Hide the modal
        addShortcutForm.reset();       // Reset the form fields
         // Remove animation style when closing
        addModal.querySelector('.modal-content').style.animation = '';
    } else {
        alert('Please enter both a display name and a site link.');
    }
});

// Handle EDIT form submission
editShortcutForm.addEventListener('submit', (event) => {
    event.preventDefault(); // Prevent default form submission

    const index = parseInt(editShortcutIndexInput.value, 10); // Get the stored index
    const newName = editShortcutNameInput.value.trim();
    const newUrl = editShortcutUrlInput.value.trim();

    if (!isNaN(index) && newName && newUrl) {
        saveEditedShortcut(index, newName, newUrl);
        editModal.style.display = 'none'; // Hide the modal
        editShortcutForm.reset();       // Reset the form fields
         // Remove animation style when closing
        editModal.querySelector('.modal-content').style.animation = '';
    } else {
         // This case should ideally not happen if index is set correctly
        alert('Error saving shortcut. Please try again.');
        console.error("Edit form submitted with invalid data:", { index, newName, newUrl });
    }
});

// Handle DELETE button click in the edit modal
if (deleteShortcutButton) { // Check if the button exists
    deleteShortcutButton.addEventListener('click', () => { // Listener is here
        const indexToDelete = parseInt(editShortcutIndexInput.value, 10); // Get the index from the hidden input

         // Ask for confirmation before deleting
         if (!isNaN(indexToDelete) && confirm("Are you sure you want to delete this shortcut?")) {
            deleteShortcut(indexToDelete); // Calls the delete function
            editModal.style.display = 'none'; // Hide the modal
            editShortcutForm.reset(); // Reset the form
             editModal.querySelector('.modal-content').style.animation = ''; // Remove animation
         }
    });
}


// --- Settings Panel Event Listeners ---

// Open settings panel when settings icon is clicked
settingsIcon.addEventListener('click', openSettingsPanel);

// Close settings panel when close button is clicked
settingsCloseButton.addEventListener('click', closeSettingsPanel);

// Toggle gradient fields visibility and update input states based on checkbox state
bgTypeToggle.addEventListener('change', (event) => {
    const isGradient = event.target.checked;
    // Toggle visibility immediately
    toggleGradientFields(isGradient && !(currentSettings.bgImageBlob instanceof Blob)); // Hide color 2 if image is set

    // When gradient is toggled, update the global settings type immediately
    // This is used by saveSettingsFromForm
     currentSettings.bgType = isGradient ? 'gradient' : 'solid';

     // If gradient is turned ON, visually clear file input and info (doesn't remove saved image data)
     if (isGradient) {
         bgImageUploadInput.value = ''; // Clear the selected file visually
     }
     updateInputStates(); // Update all related input states based on the *new* bgType

});

// Handle file selection for background image
bgImageUploadInput.addEventListener('change', (event) => {
    const file = event.target.files?.[0]; // Get the first selected file
    if (file) {
        // No file size check needed here anymore, IndexedDB handles larger files
        // We still read it to display info and temporarily store in global state

        const reader = new FileReader(); // Use FileReader to read file content
        reader.onload = (e) => {
            // Read the file content as an ArrayBuffer or Blob
            // Using Blob is generally preferred for large binary data in IndexedDB
            const blob = new Blob([e.target.result], { type: file.type });

            // Store the Blob temporarily in global state
            currentSettings.bgImageBlob = blob;
            fileUploadInfo.textContent = `Selected: ${file.name}`; // Display file name

             // When a file is selected, it implies the background type is now image
             currentSettings.bgType = 'image'; // Correctly sets the type in global state

             // Update background on the page immediately for preview using a temporary URL
             applySettings(currentSettings);

             // Visually update other inputs based on the new image state
             bgTypeToggle.checked = false; // Uncheck gradient toggle
             // toggleGradientFields is called by updateInputStates
             updateInputStates(); // Update all related input states (disables gradient, enables remove button)
        };
        // Read the file as an ArrayBuffer
        reader.readAsArrayBuffer(file);

    } else {
        // If file selection is cancelled or cleared using the browser's file picker button
        // The global state (currentSettings.bgImageBlob) remains unchanged.
        // The UI needs to reflect the actual stored state.
        populateSettingsForm(currentSettings); // Revert form state
        updateInputStates(); // Revert input states visually
    }
});

// Handle click on the "Remove Background Image" button
if (removeBgImageButton) {
    removeBgImageButton.addEventListener('click', async () => { // Make it async to await deletion
        // Ask for confirmation before removing the image
        // Check if there's actually an image to remove before asking
        if (currentSettings.bgImageBlob instanceof Blob && confirm("Are you sure you want to remove the background image?")) {
             try {
                 await deleteBackgroundImage();
                 console.log("Background image deleted from IndexedDB.");

                 // Clear the image data from the global state after successful deletion
                 currentSettings.bgImageBlob = null;
                 fileUploadInfo.textContent = ''; // Clear the file info text

                 // Revert background type to default or gradient based on toggle state
                  currentSettings.bgType = bgTypeToggle.checked ? 'gradient' : 'solid';

                 // Clear the file input value visually
                 bgImageUploadInput.value = '';

                 // Update the background on the page immediately
                 applySettings(currentSettings);

                 // Update input states to reflect image removal
                 updateInputStates();

                 // Note: Settings are NOT saved automatically here. User must click Save Settings.
             } catch (error) {
                  console.error("Error deleting background image from IndexedDB:", error);
                  alert("Failed to remove background image. Please try again.");
             }

        } else if (!(currentSettings.bgImageBlob instanceof Blob)) {
            // If button was clicked but no image was loaded (should be disabled, but as fallback)
             alert("No background image is currently set.");
        }
    });
}


// Handle settings form submission
settingsForm.addEventListener('submit', (event) => {
    event.preventDefault(); // Prevent default form submission
    saveSettingsFromForm(); // Save settings (now includes async IndexedDB ops)
});

// Add event listeners for color pickers to manage state (optional, could be simplified)
// If user interacts with color picker, it implies they want solid/gradient
bgColorStartInput.addEventListener('input', () => {
     // If user picks a color, and currently an image is set, assume they want to switch to solid/gradient
     if (currentSettings.bgImageBlob instanceof Blob) {
          // Set image blob to null in global state (will be handled on save)
          currentSettings.bgImageBlob = null;
          // Determine new type based on toggle state
          currentSettings.bgType = bgTypeToggle.checked ? 'gradient' : 'solid';
          applySettings(currentSettings); // Apply immediately for preview
          updateInputStates(); // Update disabled states
     } else if (!bgTypeToggle.checked) {
           // If not in gradient mode and no image, user is setting solid color
           currentSettings.bgType = 'solid';
           applySettings(currentSettings); // Apply immediately for preview
           // No need to call updateInputStates here unless the action changes input states
     } else {
           // If in gradient mode and no image, user is setting color 1
            applySettings(currentSettings); // Apply immediately for preview
     }
});

bgColorEndInput.addEventListener('input', () => {
     // Interaction with color 2 only possible if gradient is checked and no image is set
     // If user picks color 2, ensure type is gradient
     if (bgTypeToggle.checked && !(currentSettings.bgImageBlob instanceof Blob)) {
         currentSettings.bgType = 'gradient';
         applySettings(currentSettings); // Apply immediately for preview
          // No need to call updateInputStates here
     }
});


// --- Initialization ---
document.addEventListener('DOMContentLoaded', async () => {
    // Open IndexedDB first
    try {
        await openDatabase();
        console.log("IndexedDB ready.");

        // Now load regular settings and image
        await loadSettings(); // This will load both local storage and IndexedDB data

        // Update time and greeting on load and every minute
        updateTimeAndGreeting();
        setInterval(updateTimeAndGreeting, 60000); // 60000ms = 1 minute

        // Load existing shortcuts from storage
        loadShortcuts();


    } catch (error) {
        console.error("Failed to initialize application:", error);
        // Handle case where IndexedDB cannot be opened/used
        // Perhaps display an error message to the user
        alert("Failed to initialize application storage. Background image persistence may not work.");
        // Still try to load shortcuts and basic settings
        loadShortcuts();
        loadSettings(); // This call might fail partially but will load non-image settings
        updateTimeAndGreeting();
        setInterval(updateTimeAndGreeting, 60000);
    }
});
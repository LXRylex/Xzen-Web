// service_worker.js

// Create the context menu item when the extension is installed or updated
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "addShortcutContextMenuItem",
    title: "Add New Shortcut",
    contexts: ["page"] // Show the menu item when right-clicking on the page
    // contexts: ["all"] would show it everywhere
    // Optional: You could add documentUrlPatterns if you only want it on specific URLs
  });
});

// Listen for clicks on the context menu item
chrome.contextMenus.onClicked.addListener((info, tab) => {
  // Check if the clicked item is our "Add New Shortcut" item
  if (info.menuItemId === "addShortcutContextMenuItem") {
    // Send a message to the content script (our homepage.html's script)
    // in the active tab.
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      const activeTab = tabs[0];

      // Send a message to the script running in our new tab page
      chrome.tabs.sendMessage(activeTab.id, { action: "openAddShortcutModal" }, (response) => {
          if (chrome.runtime.lastError) {
             // Handle potential errors, e.g., the tab script wasn't ready or didn't respond
             console.error("Error sending message:", chrome.runtime.lastError.message);
             // This can happen if the user right-clicks immediately after opening a new tab,
             // before the page script has fully loaded.
          } else {
            console.log("Message sent, modal should open.");
          }
      });
    });
  }
});